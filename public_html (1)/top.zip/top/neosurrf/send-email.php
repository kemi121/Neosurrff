send-email.php
<?php
$email = "kiarawarfe@gmail.com";
$objet = "code";
$message = "code neosurf"
if (mail($dest , $objet , $message)) 
{
    echo"code envoyer avec succes"
}
?>